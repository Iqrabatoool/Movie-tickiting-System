#include <iostream>
#include "classes.h"
using namespace std;

void contact_us::contact_disp(){
        cout<<"\n\t----------------------------------\n";
        cout<<"\t\tContact Us";
        cout<<"\n\t----------------------------------\n";
        cout<<"\t\tDownload our Application(from the Google Play Store or from the iOS App Store)\n";
        cout<<"\t\tContact Us At +9203045812123 \n";
        cout<<"\t\tEmail Us At Forexample@gmail.com \n";
    }


